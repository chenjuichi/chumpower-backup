import mitt from 'mitt';

const eventBus = mitt();

export default eventBus;