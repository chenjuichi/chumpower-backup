import { ref } from 'vue';

export const snackbar = ref(false);
export const snackbar_info = ref('');
export const snackbar_color = ref('red accent-2');