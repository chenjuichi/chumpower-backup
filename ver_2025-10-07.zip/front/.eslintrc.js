module.exports = {
    // 其他設定
    rules: {
      'no-empty': 'off', // 禁用 no-empty 規則
    },
  };