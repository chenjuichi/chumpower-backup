#from server import app

#from server.relation.tables import User, Area, Layout, Work, Customer, Product, Session

#from server import views